void seatManagement()
  {
   	int arr[5][5];
	 for(int i=0; i<5; i++)
	   {
		 for(int j=0; j<5; j++)
	  	  {
				arr[i][j]=0;
		  }
		}
	 int number;
	 bool condition = true ;
	 while (condition)
	  {
	     cout<<"\n\n====== Manage Seat Assignments ======\n\n"<<endl;
	     cout<<"1.View Seating Arrangement"<<endl;
	     cout<<"2.Book a Seat"<<endl;
	     cout<<"3.Return to Main Menu\n\n"<<endl;
	     cout<<"=====================================\n"<<endl;
	     cout<<"Enter Choice : ";
	     cin>>number;
	     if(number==1)
	     {
	 	     seats(arr, number);
	       }
	     else if(number==2)
	     {
	 	     seats(arr, number);
	       }
	     else
		 {
	 	     condition = false ;
	       }
		}
	}

    