void Schedule(){
	int option;
	cout<<"\n\n====== Schedule Of Movies======\n"<<endl;
	
	
	menu:
	cout<<"1.Romantic \n2.Comedy \n3.Horror \n4.Action"<<endl;
	cout<<"Enter Your Category To See Schedule : ";
	cin>>option;
   
	
	
	switch(option)
	{
	case 1:
	cout<<"\n============Romantic================\n"<<endl;	
	cout<<"8:00 PM  - Dilwale Movie"<<endl;
 	cout<<"10:30 PM - Notebook Movie"<<endl;
 	cout<<"12:00 PM - My Fault Movie"<<endl;
 	cout<<"2: 00 AM -  Laila Majnu Movie"<<endl;
 	cout<<"\n====================================\n"<<endl;
    break;
    case 2:
    cout<<"\n============Comedy================\n"<<endl;
    cout<<"8:00 PM  - Three Idiots"<<endl;
 	cout<<"10:30 PM - PK"<<endl;
 	cout<<"12:00 PM - Babylon"<<endl;
 	cout<<"2: 00 AM - Goolmaal"<<endl;
 	 cout<<"\n=================================\n"<<endl;
    break;
    case 3:
    	cout<<"\n===========Horror===============\n"<<endl;
    cout<<"8:00 PM  - Unfriended Dark Web Movie"<<endl;
 	cout<<"10:30 PM - The Lie Movie"<<endl;
 	cout<<"12:00 PM - Cold Case Movie"<<endl;
 	cout<<"2: 00 AM - Closing Ceremony "<<endl;
 	 cout<<"\n===================================\n"<<endl;
    break;
    case 4:
    cout<<"\n==============Action==============\n"<<endl;
    cout<<"8:00 PM  - Mission:Impossible Movie"<<endl;
 	cout<<"10:30 PM - Skyscraper Movie"<<endl;
 	cout<<"12:00 PM - War Movie"<<endl;
 	cout<<"2: 00 AM - Tiger Zinda Hai Movie"<<endl;
 	 cout<<"\n=================================\n\n"<<endl;
 	break;
 	 default:
 		cout<<"Invalid Choice,Select from(1-4)"<<endl;
 		goto menu;
	}
	cout<<"That was schedule"<<endl;
}
