void exit(bool& condition)
  {
	 int choice;
     while (choice != 1 && choice != 2)
	 {
         cout << "\n1: Return to Main Menu" << endl;
         cout << "2: Exit" << endl;
         cout << "\nEnter your choice (1 or 2): ";
         cin >> choice;
          if (choice == 1)
		 {
            break;
         } 
		 else if (choice == 2) 
		 {
             cout << "\nThank you for using the Online Ticket Booking System! Goodbye!\n";
             condition = false;
             break;
         }
		  else 
		  {
             cout << "\nInvalid input! Please try again.\n";
          }
		}
	}
		
