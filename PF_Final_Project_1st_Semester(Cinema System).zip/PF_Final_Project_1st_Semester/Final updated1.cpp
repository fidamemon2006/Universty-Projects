#include<iostream>
using namespace std;

#include "resgistrationOfGuests.h"
#include "Schedule.h"
#include "ticketBooking.h"
#include "seats.h"
#include "seatManagement.h"

#include "exit.h"

int main(){
	int choice;
	int arr[5][5]={0};
	bool condition = true ;
	
	while(condition){
	cout<<"\n\n===== Online Cinema Booking System =====\n\n"<<endl;
	cout<<"1.Register Your Names."<<endl;
	cout<<"2.See Schedule Of Movies."<<endl;
	cout<<"3.Book Your Tickets."<<endl;
	cout<<"4.See Seats Arrangment."<<endl;
	cout<<"5.Exit. \n\n"<<endl;
	cout<<"===========================================\n\n"<<endl;
	cout<<"Enter Choice : ";
	
	cin>>choice;
   if(choice==1)
   {
		resgistrationOfGuests();
		cout<<"\n\nCustomers Names are Registered Would you like Move on Main Menu or Exit "<<endl;
		exit(condition);
	}   
  else if(choice==2)
   {
		Schedule();
		exit(condition);
	}
	else if(choice==3)
	{
	    ticketBooking();
    	cout<<"\n\nNow Tickets are Booked !!"<<endl;
    	exit(condition);
	}
	else if(choice==4)
	{
		seatManagement();
		exit(condition);
	}
	else if(choice==5)
	{   
	   
	   cout<<"\nThank you For coming !!!! Good Bye !!!";
	   condition = false;
	}
	else
	{
		cout<<"Please Select Valid Option From(1-5)";
	}
}
}


