void resgistrationOfGuests(){
	int number;
	cout<<"\nEnter Total Number Of Customer : ";
	cin>>number;
	cin.ignore();
	string name[number];
	for(int i=0;i<number; i++){
		cout<<"\nEnter Customer  "<<(i+1)<<" Name : ";
		getline(cin,name[i]);
	}
	cout<<"\nRegistered Customers:"<<endl;
	
	for(int i=0;i<number;i++)
	{
	  cout<<(i+1)<<"."<<name[i]<<endl;
	}
}
