void ticketBooking(){
	int number;
	int option;
	cout<<"\n\nEnter Number of Tickets : ";
	cin>>number;
	cout<<"\nEnter Your Category:"<<endl;
	menu:
    cout<<"1.VIP($100) \n2.REGULAR($50) \n3. cancel ticket "<<endl;
    cin>>option;
    if(option == 1){
		cout<<"Total Price for "<<number<<" is $"<<number*100<<endl;
	}
	else if(option == 2){
		cout<<"Total Price for "<<number<<" is $"<<number*50<<endl;
	}
	else if(option == 3){
		goto menu;
	}
	else{
		cout<<"\nInvalid choice. Select Between (1 - 2)"<<endl;
		goto menu;
	}
	}
