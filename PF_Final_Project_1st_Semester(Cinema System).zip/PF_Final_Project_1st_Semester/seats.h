void seats(int arr[][5],int choice){
	int row , column;
	switch(choice){
		case 1:
		cout<<"Seating Arrangment: 0-vacant 1-ocuupied\n"<<endl;
		for(int i=0; i<5; i++){
			for(int j=0; j<5; j++){
				cout<<arr[i][j]<<" ";
			}
			cout<<endl;
		}
		break;
		case 2:	
		while(true)
		{
		 cout<<"Enter Row Number (0-4):";
		 cin>>row;
		 cout<<"Enter Column Number (0-4):";
		 cin>>column;
		 if(row<0 || row>4 && column<0 || column>4)
		   {
			 cout<<"\nInvalid Input !!! \n"; 
			 continue;
		   }
     	 if(arr[row][column]==1)
		  {
             cout<<"\n\nSeat already booked! Please choose another seat.\n\n";
           }
          arr[row][column]=1;
		 cout<<"\n\nSeat Booked SuccessFully\n"<<endl;
		 break;
		}
	 break;
     default:
        cout<<"System Eroor!!!"<<endl;
        }
   }  
	
